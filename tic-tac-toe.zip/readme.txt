Running the project:
1. run npm install
2. run bower install
3. npm start
4. run chrome localhost:5000

Project:
This is a tic tac toe SPA game, build with Angular and node.js-express,
also used some bootstrap and chart.js.

@Dudu_Lemberberg
